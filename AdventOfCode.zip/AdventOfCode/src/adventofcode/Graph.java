package adventofcode;

import java.util.LinkedList;
import java.util.Queue;

public class Graph {
//	private int depth = Integer.MAX_VALUE;
	private Node rootNode;

	public Graph(Node rootNode) {
		super();
		this.rootNode = rootNode;
	}

	public Object compute() {
		Queue<Node> queue = new LinkedList<>();
		queue.add(rootNode);

		rootNode.setVisited(true);
		while (!queue.isEmpty()) {
			System.out.println("queue size=" + queue.size());
			Node node = (Node) queue.remove();
			for (Node childNode : node.getUnvisitedChildNodes()) {
				childNode.setVisited(true);
				queue.add(childNode);

				if (childNode.finish()) {
					return childNode.getResult();
				}
			}
		}
		
		return null;
	}
}
