package adventofcode;

import java.util.ArrayList;
import java.util.Collection;

public abstract class Node {
	private boolean visited = false;
	private Collection<Node> children;

	public Node() {
		super();
		this.children = new ArrayList<Node>();
	}

	public boolean isVisited() {
		return visited;
	}

	public void setVisited(boolean visited) {
		this.visited = visited;
	}

	public Collection<Node> getChildren() {
		return children;
	}

	/**
	 * Get the child nodes, of the current node, that shall be visited in the
	 * next step
	 * 
	 * @return the list of the child nodes that shall be visited
	 */
	public abstract Collection<Node> getUnvisitedChildNodes();

	public abstract boolean finish();

	public abstract Object getResult();
}
