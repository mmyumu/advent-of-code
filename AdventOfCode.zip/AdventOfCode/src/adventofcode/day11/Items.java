package adventofcode.day11;

import java.util.HashSet;
import java.util.Iterator;

public class Items extends HashSet<Item> {
	private static final long serialVersionUID = 1L;

	public Items() {
		super();
	}

	@Override
	public String toString() {
		Iterator<Item> it = iterator();
		if (!it.hasNext())
			return "[]";

		StringBuilder sb = new StringBuilder();
		sb.append('[');
		for (;;) {
			Item item = it.next();
			sb.append(item.getName() + "-" + item.getType());
			if (!it.hasNext())
				return sb.append(']').toString();
			sb.append(',').append(' ');
		}
	}
}
