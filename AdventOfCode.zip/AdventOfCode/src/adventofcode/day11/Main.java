package adventofcode.day11;

import adventofcode.Graph;

public class Main {
	public static void main(String[] args) {
		Input sampleInput = new Input(4);
		sampleInput.add(0, "hydrogen", "microship");
		sampleInput.add(0, "lithium", "microship");
		sampleInput.add(1, "hydrogen", "generator");
		sampleInput.add(2, "lithium", "generator");

		Input initialInput = new Input(10);
		initialInput.add(0, "promethium", "generator");
		initialInput.add(0, "promethium", "microship");
		initialInput.add(1, "cobalt", "generator");
		initialInput.add(1, "curium", "generator");
		initialInput.add(1, "ruthenium", "generator");
		initialInput.add(1, "plutonium", "generator");
		initialInput.add(2, "cobalt", "microship");
		initialInput.add(2, "curium", "microship");
		initialInput.add(2, "ruthenium", "microship");
		initialInput.add(2, "plutonium", "microship");

		State rootState = new State(sampleInput, 0, 0);
		Graph graph = new Graph(rootState);
		int result = (int) graph.compute();
		System.out.println("result=" + result);
//		rootState.compute();
		

//		Set<Item> items1 = new HashSet<Item>();
//		items1.add(new Item("toto", "generator"));
//		items1.add(new Item("tata", "generator"));
//
//		Set<Item> items2 = new HashSet<Item>();
//		items2.add(new Item("tata", "generator"));
//		items2.add(new Item("toto", "generator"));
//
//		System.out.println("items1 equals items2 -> " + items1.equals(items2));
//		System.out.println("items1 contains tata -> " + items1.contains(new Item("tata", "generator")));

		System.out.println("Minimum depth=" + State.minDepth);
	}
}
