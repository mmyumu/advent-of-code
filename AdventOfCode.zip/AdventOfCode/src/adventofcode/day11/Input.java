package adventofcode.day11;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Input {
	private int numberOfObjects;
	private List<Items> floors;

	public Input(int numberOfObjects) {
		super();
		this.numberOfObjects = numberOfObjects;
		this.floors = new ArrayList<Items>(4);

		floors.add(new Items());
		floors.add(new Items());
		floors.add(new Items());
		floors.add(new Items());
	}

	public boolean add(int floor, String name, String type) {
		return floors.get(floor).add(new Item(name, type));
	}

	public boolean remove(int floor, String name, String type) {
		return floors.get(floor).remove(new Item(name, type));
	}

	public Set<Item> getItems(int floor) {
		return floors.get(floor);
	}

	public Input copy() {
		Input copyInput = new Input(numberOfObjects);

		for (int floor = 0; floor < floors.size(); floor++) {
			for (Item item : floors.get(floor)) {
				copyInput.add(floor, item.getName(), item.getType());
			}
		}

		return copyInput;
	}

	@Override
	public String toString() {
		StringBuilder str = new StringBuilder();

		str.append("F4 ");
		str.append(floors.get(3));
		str.append("\nF3 ");
		str.append(floors.get(2));
		str.append("\nF2 ");
		str.append(floors.get(1));
		str.append("\nF1 ");
		str.append(floors.get(0));

		return str.toString();
	}

	public boolean isFinished() {
		return floors.get(3).size() == numberOfObjects;
	}

	public boolean isValid() {
		for (Set<Item> items : floors) {
			if (!checkItems(items)) {
				return false;
			}
		}
		return true;
	}

	private boolean checkItems(Collection<Item> items) {
		for (Item item : items) {
			if (item.isMicroship()) {
				if (!item.isConnected(items)) {
					if (item.hasOtherGenerator(items)) {
						return false;
					}
				}
			}
		}
		return true;
	}

	public boolean compare(Input otherInput) {
		for (int floor = 0; floor < floors.size(); floor++) {
			boolean result = compare(floors.get(floor), otherInput.floors.get(floor));
			if (!result) {
				return false;
			}
		}
		return true;
	}

	private boolean compare(Set<Item> items, Set<Item> otherItems) {
		Set<Item> set = new HashSet<Item>(items);
		Set<Item> otherSet = new HashSet<Item>(otherItems);

		return set.equals(otherSet);
	}
}
