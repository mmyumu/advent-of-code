package adventofcode.day11;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import adventofcode.Node;

public class State extends Node {
	public static int minDepth = Integer.MAX_VALUE;
	private static final Map<Integer, List<Integer>> possibleFloors;
	private State rootState;
	private Input input;
	private int floor;
	private int depth;

	static {
		possibleFloors = new HashMap<Integer, List<Integer>>();
		possibleFloors.put(0, Arrays.asList(1));
		possibleFloors.put(1, Arrays.asList(0, 2));
		possibleFloors.put(2, Arrays.asList(1, 3));
		possibleFloors.put(3, Arrays.asList(2));
	}

	public State(Input input, int floor, int depth) {
		super();
		this.rootState = this;
		this.input = input;
		this.floor = floor;
		this.depth = depth;
	}

	public State(State rootState, Input input, int floor, int depth) {
		super();
		this.rootState = rootState;
		this.input = input;
		this.floor = floor;
		this.depth = depth;
	}

	private void print(Object obj) {
		StringBuilder indent = new StringBuilder();
		for (int index = 0; index < depth; index++) {
			indent.append("\t");
		}

		String msg = obj.toString().replaceAll("\n", "\n" + indent.toString());

		System.out.println(indent + msg);
	}

	// public boolean compute() {
	// print("Depth=" + depth);
	// print(input);
	//
	// if (depth >= minDepth) {
	// print("Depth too big!");
	// return false;
	// }
	//
	// if (isFinished()) {
	// print("Solution found with depth: " + depth);
	// minDepth = depth;
	// return true;
	// }
	//
	// if (!isValid()) {
	// print("Microship fried!");
	// return false;
	// }
	//
	// if (isStateAlreadyCheckedAndBetter(rootState)) {
	// print("Already checked!");
	// return false;
	// }
	//
	// Set<Items> combinations = getPossibleCombinations();
	//
	// print("Try all following combinations -> " + combinations);
	// for (Integer newFloor : possibleFloors.get(floor)) {
	// for (Items combination : combinations) {
	// print("Take " + combination + " from " + (floor+1) + " to " +
	// (newFloor+1));
	//
	// Input newInput = computeNewInput(newFloor, combination);
	// State newState = new State(rootState, newInput, newFloor, depth + 1);
	// children.add(newState);
	// boolean result = newState.compute();
	// }
	// }
	//
	// // Dead end
	// return false;
	// }
	//
	private Input computeNewInput(Integer newFloor, Items combination) {
		Input newInput = input.copy();

		for (Item item : combination) {
			newInput.remove(floor, item.getName(), item.getType());
			newInput.add(newFloor, item.getName(), item.getType());
		}

		return newInput;
	}

	// private boolean isStateAlreadyCheckedAndBetter(State state) {
	// if (state != this && floor == state.floor && state.input.compare(input))
	// {
	// return true;
	// }
	//
	// for (State childState : state.getChildren()) {
	// boolean result = isStateAlreadyCheckedAndBetter(childState);
	// if (result) {
	// return true;
	// }
	// }
	//
	// return false;
	// }
	//
	// private boolean isFinished() {
	// return input.isFinished();
	// }
	//
	// private boolean isValid() {
	// return input.isValid();
	// }

	@Override
	public Collection<Node> getUnvisitedChildNodes() {
		List<Node> unvisitedNode = new ArrayList<>();
		for (Integer newFloor : possibleFloors.get(floor)) {
			for (Items combination : getPossibleCombinations()) {
				Input newInput = computeNewInput(newFloor, combination);
				State newState = new State(rootState, newInput, newFloor, depth + 1);

				if (!newState.isAlreadyExisting()) {
					unvisitedNode.add(newState);
				}

				print("Take " + combination + " from " + (floor + 1) + " to " + (newFloor + 1));
			}
		}

		return unvisitedNode;
	}

	/**
	 * Check if the state is already existing in the whole tree
	 * 
	 * @return true if it is existing, false otherwise
	 */
	private boolean isAlreadyExisting() {
		return isAlreadyExisting(rootState);
	}

	/**
	 * Check if the state is already existing in the tree defined by the given
	 * root (otherState)
	 * 
	 * @param otherState
	 *            the root of the tree to test
	 * @return true if it is existing, false otherwise
	 */
	private boolean isAlreadyExisting(State otherState) {
		if (this != otherState && input.compare(otherState.input)) {
			return true;
		}

		for (Node childNode : otherState.getChildren()) {
			State childState = (State) childNode;
			boolean result = isAlreadyExisting(childState);
			if (result) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Get the combinations of items that can be moved from the current floor
	 * 
	 * @return the combinations of items
	 */
	private Set<Items> getPossibleCombinations() {
		Set<Items> combinations = new HashSet<Items>();

		Collection<Item> itemsFromFloor = input.getItems(floor);

		for (Item item1 : itemsFromFloor) {
			{
				Items items = new Items();
				items.add(item1);

				if (!combinations.contains(items)) {
					combinations.add(items);
				}
			}
			for (Item item2 : itemsFromFloor) {
				if (item1 != item2) {
					Items items = new Items();
					items.add(item1);
					items.add(item2);
					if (!combinations.contains(items)) {
						combinations.add(items);
					}
				}
			}
		}
		return combinations;
	}

	@Override
	public boolean finish() {
		return input.isFinished();
	}

	@Override
	public Object getResult() {
		return depth;
	}
}
